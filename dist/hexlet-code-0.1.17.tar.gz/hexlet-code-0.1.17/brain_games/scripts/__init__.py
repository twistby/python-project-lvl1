"""Brain games scripts."""
