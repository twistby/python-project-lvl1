"""Brain game packet."""
